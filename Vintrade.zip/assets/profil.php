<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/profil.css">
    <title>Profil</title>
</head>
<body>

<?php include ('assets/affichage_commentaire.php'); ?>


    <div class="content-description">
        <div class="content-avatar">
            <div class="avatar"></div>
            <div class="pseudo-avis">
                <p>Baptiste.L</p>
                <p>Avis des utilisateurs : ***** (155 évaluations) </p>
            </div>
        </div>

        <div class="description-profil">
            <p>À propos : </p>
            <p>Toulouse, France</p>
            <p>xxx abonnés, xxx abonnements.</p>
            <p>Description de l'utilisateur : </p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque rerum minima nam deleniti, omnis cupiditate voluptatem laudantium alias, incidunt officia voluptatibus perferendis excepturi eum asperiores fuga, eligendi laboriosam dolorum porro!
            Enim soluta accusantium omnis nulla assumenda quam officiis tempora quis obcaecati ea quibusdam unde laboriosam voluptas, aspernatur quasi laborum magnam dolor harum! Qui aliquam expedita adipisci dicta rem itaque perferendis.</p>
        </div>
    </div>

</body>
</html>