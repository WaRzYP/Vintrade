<?php


session_start();


session_destroy();


                // ../index.php ou ./index.php ?
    header("Location: ../index.php");

?>