<?php

$bddserver = "localhost"; 
$bddname = "vintrade"; 
$bddlogin = "root";
$bddpass = ""; 